alter table TAZACOM_BOOK add column AUTHOR varchar(36) ;
alter table TAZACOM_BOOK drop column AUTHOR_ID cascade ;
