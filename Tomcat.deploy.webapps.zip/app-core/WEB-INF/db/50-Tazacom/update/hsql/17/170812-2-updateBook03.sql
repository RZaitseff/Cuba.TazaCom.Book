alter table TAZACOM_BOOK add constraint FK_TAZACOM_BOOK_AUTHOR foreign key (AUTHOR) references TAZACOM_AUTHOR(ID);
