update TAZACOM_IMPORTING set DATE_ = current_date where DATE_ is null ;
alter table TAZACOM_IMPORTING alter column DATE_ set not null ;
