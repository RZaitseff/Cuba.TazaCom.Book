alter table TAZACOM_BOOK add column LAST_NAME varchar(36) ;
alter table TAZACOM_BOOK drop column AUTHOR_ID cascade ;
