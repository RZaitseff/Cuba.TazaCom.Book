alter table TAZACOM_GENRE alter column NAME set data type varchar(50) ;
