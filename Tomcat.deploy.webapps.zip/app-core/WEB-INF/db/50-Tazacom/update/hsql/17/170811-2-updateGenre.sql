alter table TAZACOM_GENRE drop column BOOK_COLLECTION cascade ;
