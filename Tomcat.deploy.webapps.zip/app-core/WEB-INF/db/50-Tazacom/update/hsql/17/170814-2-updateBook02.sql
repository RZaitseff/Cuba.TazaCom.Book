alter table TAZACOM_BOOK add column IMPORTING_ID varchar(36) ;
alter table TAZACOM_BOOK drop column IMPORT_URL_ID cascade ;
