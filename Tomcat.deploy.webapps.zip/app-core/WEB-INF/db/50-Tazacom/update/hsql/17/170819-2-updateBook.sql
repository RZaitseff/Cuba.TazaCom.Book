alter table TAZACOM_BOOK drop column IMPORTING_ID cascade ;
