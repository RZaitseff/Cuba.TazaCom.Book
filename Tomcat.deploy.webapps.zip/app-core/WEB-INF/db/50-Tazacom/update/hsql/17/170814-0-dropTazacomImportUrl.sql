drop table TAZACOM_IMPORT_URL cascade ;
