create table TAZACOM_BOOK_GENRE_LINK (
    BOOK_ID varchar(36) not null,
    GENRE_ID varchar(36) not null,
    primary key (BOOK_ID, GENRE_ID)
);
