update TAZACOM_IMPORTING set STATE = '10' where STATE is null ;
alter table TAZACOM_IMPORTING alter column STATE set not null ;
