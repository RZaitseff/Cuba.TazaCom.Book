alter table TAZACOM_IMPORT_URL add column QUANTITY integer ;
