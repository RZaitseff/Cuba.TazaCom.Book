alter table TAZACOM_GENRE drop column STATE cascade ;
alter table TAZACOM_GENRE add column STATE varchar(50) ;
