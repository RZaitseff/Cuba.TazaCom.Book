alter table TAZACOM_BOOK add column IMPORT_URL_ID varchar(36) ;
