alter table TAZACOM_BOOK add constraint FK_TAZACOM_BOOK_AUTHOR foreign key (AUTHOR_ID) references TAZACOM_AUTHOR(ID);
create index IDX_TAZACOM_BOOK_AUTHOR on TAZACOM_BOOK (AUTHOR_ID);
