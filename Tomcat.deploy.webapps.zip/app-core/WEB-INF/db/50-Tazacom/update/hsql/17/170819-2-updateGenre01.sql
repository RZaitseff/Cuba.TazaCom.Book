create unique index IDX_TAZACOM_GENRE_UNQ on TAZACOM_GENRE (NAME) ;
