alter table TAZACOM_BOOK_GENRE_LINK add constraint FK_TBGL_BOOK foreign key (BOOK_ID) references TAZACOM_BOOK(ID);
alter table TAZACOM_BOOK_GENRE_LINK add constraint FK_TBGL_GENRE foreign key (GENRE_ID) references TAZACOM_GENRE(ID);
