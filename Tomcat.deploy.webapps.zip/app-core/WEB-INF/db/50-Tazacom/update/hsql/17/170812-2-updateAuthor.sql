alter table TAZACOM_AUTHOR drop column STATE cascade ;
alter table TAZACOM_AUTHOR add column STATE varchar(50) ;
