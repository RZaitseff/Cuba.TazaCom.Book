alter table TAZACOM_BOOK add column AUTHOR_LAST_NAME varchar(36) ;
alter table TAZACOM_BOOK drop column LAST_NAME cascade ;
