alter table TAZACOM_BOOK drop column GENRE_COLLECTION cascade ;
