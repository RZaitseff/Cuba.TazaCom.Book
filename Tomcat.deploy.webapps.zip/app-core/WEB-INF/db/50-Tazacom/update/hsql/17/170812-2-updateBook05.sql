alter table TAZACOM_BOOK drop column STATE cascade ;
alter table TAZACOM_BOOK add column STATE varchar(50) ;
