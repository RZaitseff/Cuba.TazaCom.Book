drop table TAZACOM_BOOK_GENRE_LINK cascade ;
