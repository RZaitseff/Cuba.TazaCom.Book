alter table TAZACOM_BOOK add column AUTHOR_ID varchar(36) ;
alter table TAZACOM_BOOK drop column AUTHOR cascade ;
alter table TAZACOM_BOOK alter column NAME set data type varchar(50) ;
