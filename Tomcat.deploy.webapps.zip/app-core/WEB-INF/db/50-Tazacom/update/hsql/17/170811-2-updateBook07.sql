alter table TAZACOM_BOOK add column AUTHOR_ID varchar(36) ;
alter table TAZACOM_BOOK drop column AUTHOR_LAST_NAME cascade ;
