-- Description:
alter table SYS_APP_FOLDER add column APPLY_DEFAULT boolean;
alter table SEC_SEARCH_FOLDER add column APPLY_DEFAULT boolean;
