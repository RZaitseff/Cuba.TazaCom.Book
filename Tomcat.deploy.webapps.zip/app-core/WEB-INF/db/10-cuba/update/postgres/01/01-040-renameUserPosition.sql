-- Description: sec_user.position field

alter table sec_user rename column position to position_
^
