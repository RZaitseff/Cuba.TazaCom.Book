
alter table SYS_CATEGORY_ATTR add column LOOKUP boolean;
