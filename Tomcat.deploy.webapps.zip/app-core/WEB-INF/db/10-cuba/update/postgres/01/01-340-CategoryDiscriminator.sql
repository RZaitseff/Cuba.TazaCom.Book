-- Description:

alter table SYS_CATEGORY add DISCRIMINATOR integer;