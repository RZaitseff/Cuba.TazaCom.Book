-- Description:
alter table SYS_CATEGORY_ATTR add ORDER_NO integer;