alter table SYS_ATTR_VALUE add column CODE varchar(100);
alter table SYS_CATEGORY_ATTR add column TARGET_SCREENS varchar(4000);

