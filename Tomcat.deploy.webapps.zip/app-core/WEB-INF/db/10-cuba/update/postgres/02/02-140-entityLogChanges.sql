-- Description: add SEC_ENTITY_LOG.CHANGES

alter table SEC_ENTITY_LOG add CHANGES text;
