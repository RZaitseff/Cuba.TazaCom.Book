
alter table SEC_CONSTRAINT alter WHERE_CLAUSE type varchar(1000);