-- Increase length of SEC_CONSTRAINT columns

alter table SEC_CONSTRAINT alter column GROOVY_SCRIPT type text^

alter table SEC_CONSTRAINT alter column FILTER_XML type text^
