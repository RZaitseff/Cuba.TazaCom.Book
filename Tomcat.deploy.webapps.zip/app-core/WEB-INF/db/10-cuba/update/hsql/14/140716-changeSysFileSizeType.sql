-- Description: Change type of column FILE_SIZE in SYS_FILE table

alter table SYS_FILE alter column FILE_SIZE bigint^