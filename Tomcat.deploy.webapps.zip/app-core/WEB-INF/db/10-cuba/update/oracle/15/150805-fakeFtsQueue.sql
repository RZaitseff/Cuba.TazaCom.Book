alter table SYS_FTS_QUEUE add FAKE char(1)^
