alter table SEC_CONSTRAINT add IS_ACTIVE char(1) default '1'^

