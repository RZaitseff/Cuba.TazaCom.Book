
alter table SYS_SCHEDULED_TASK add DESCRIPTION varchar(1000);