package ru.zrv.tazacom.web.importing;

import com.haulmont.cuba.gui.components.AbstractEditor;
import ru.zrv.tazacom.entity.Importing;

public class ImportingEdit extends AbstractEditor<Importing> {
}