package ru.zrv.tazacom.web.util.reader;

import java.io.IOException;

import org.json.JSONArray;
import org.json.JSONObject;

import ru.zrv.tazacom.web.util.Logger;


/**
 * 
 * @author Roman.Zaytseff
 */
public class ResourceReader {
	
	public String getUriRequest(String url) {
		String error = "NOK";
		JSONArray books = null;
		JSONObject answer = new JSONObject();
		answer.put("answerCode", ("----- >  Import start yet"));
					
		// Read JSONArray from source uri link
		try {
			books = ResourceReaderFabrica.gather(url);
			
			if(books != null && books.length() > 0) {
				error = "OK";
			} else if (books != null && books.length() == 0) {
				error =  "----- >  Book list is Empty";
			} else {
				error =  "----- >  Import ERROR";
			}

		} catch (IOException e) {
			error = "----- >  IO ERROR: \n" + e;
			 loggerError(url);
			 logger.error(e.getMessage());
			 e.printStackTrace();
		}
		
		answer.put("answerCode", error);
		answer.put("answer", books);
		return answer.toString();
	}

	private static Logger logger = new Logger(ResourceReader.class.getName());

	private static void loggerError(String uri) {
		logger.error("Can't recognize uri = " + uri 
				+ " -----> So will be used DEFAULT startegy with this file path");
	}
}
