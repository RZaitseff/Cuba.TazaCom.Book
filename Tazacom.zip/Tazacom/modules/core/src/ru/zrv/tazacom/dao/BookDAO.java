package ru.zrv.tazacom.dao;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

/**
 * @author Roman Zaytseff
 * @e-mail RZaytseff@mail.ru
 */

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.haulmont.cuba.core.EntityManager;
import com.haulmont.cuba.core.Query;
import com.haulmont.cuba.core.Transaction;

import ru.zrv.tazacom.entity.Book;
import ru.zrv.tazacom.entity.Genre;
import ru.zrv.tazacom.entity.StateEnum;

@Component("bookrDAO")
//@Transactional
public class BookDAO extends _DAO<Book> {
	
	protected Logger logger = Logger.getLogger(BookDAO.class);
	
	protected String whereCondition = "where "
			+ "     e.author.firstName = :firstName "
			+ " and e.author.middleName LIKE :middleName "
			+ " and e.author.lastName = :lastName"
			+ " and e.name = :name"
			+ " and e.year = :year"
			+ " and e.edition = :edition"
			;

	@Override
	protected String getWhere() {
		return whereCondition;
	}
	protected Query query(String query, Book book) {
		return getEM().createQuery(query)
				.setParameter("firstName",   book.getAuthor().getFirstName())
				.setParameter("lastName",    book.getAuthor().getLastName())
				.setParameter("middleName", (book.getAuthor().getMiddleName() != null ? book.getAuthor().getMiddleName() : ""))
				.setParameter("name",        book.getName())
				.setParameter("year",        book.getYear())
				.setParameter("edition",     book.getEdition())
				;
	}
	
	@Inject 
	GenreDAO genreDAO;
	
	public Book connectBookWithGenres(Book book, List<Genre> genres) {
		logger.error("---------------- >>>>>>>>> count books of " + book.getName() + " = " + count(book));		
		try (Transaction tx = persistence.createTransaction())  {
			EntityManager em = getEM();
			List<Genre> genreList = new ArrayList<>();
			book = em.find(Book.class, book.getId()); // book = include(book);
			if(genreList != null) {
				for(Genre genre: genres) {
					genre = em.find(Genre.class, genre.getId());
					book.getGenre().add(genre);
				}
			}
			em.merge(book);
			em.flush();
			tx.commit();
		}
		
		logger.error("!!!!!!!!!!!!!!!---------------- >>>>>>>>> count books of " + book.getName() + " = " + count(book));		
		return book;
	}
}
